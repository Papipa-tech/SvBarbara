# Rosie Resume

This is a simple resume project made using Bootstrap 4